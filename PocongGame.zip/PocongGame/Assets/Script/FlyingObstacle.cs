﻿using UnityEngine;
using System.Collections;

public class FlyingObstacle : Obstacle {

	public GameObject[] obstacle;

	public override GameObject SelectObstacle (){
		GameObject flyingObs = obstacle [Random.Range (0, obstacle.Length)];
		return flyingObs;
	}
	public override Vector3 SpawnPoint(){
		float yPos = Random.Range (-2.75f, -1f);
		Vector3 flyingPosition = new Vector3 (transform.position.x, yPos, transform.position.z);
		return flyingPosition;
	}
}
