﻿using UnityEngine;
using System.Collections;
using System;

public class Pocong : Character {
    override public void OnCollisionEnter2D(Collision2D coll)
    {

        isJump = false;
        if (coll.gameObject.tag == "obstacle")
        {
            isDead = true;
            PlayerPrefs.SetInt("speed", 0);
            GetComponent<Animator>().Stop();
        }
        else
        {
            isDead = false;
        }
    }
    override public void duck()
    {
        //PocongCollider.size = new Vector2(5.271853f, 5.161372f);
        isSleding = true;
        GetComponent<Animator>().Play("sleding");
    }

    public override void jump()
    {
        isJump = true;
        jumpCount = 0;
        GetComponent<Rigidbody2D>().velocity = Vector2.zero;
        GetComponent<Rigidbody2D>().AddForce(jumpForce);
    }

    public void backToStandby()
    {
        PocongCollider.size = new Vector2(1.822016f, 2.977788f);
        GetComponent<Animator>().Play("luncat");
        isSleding = false;
    }

    public Rigidbody2D getRigidBody2D()
    {
        return this.rb;
    }
    public bool getSleding()
    {
        return this.isSleding;
    }

    public bool getJump()
    {
        return this.isJump;
    }

    public bool getDead()
    {
        return this.isDead;
    }
}
