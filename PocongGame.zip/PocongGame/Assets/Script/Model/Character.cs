﻿using UnityEngine;
using System.Collections;

public abstract class Character : MonoBehaviour {
    protected Vector2 jumpForce = new Vector2(0, 600);
    protected double jumpCount = 1;
    protected bool isJump=false;
    protected bool isSleding=false;
    public Rigidbody2D rb;
    protected bool isDead = false;
    protected Animator animator;
    public BoxCollider2D PocongCollider;

    public abstract void jump();
    public abstract void OnCollisionEnter2D(Collision2D coll);
    public abstract void duck();
}
