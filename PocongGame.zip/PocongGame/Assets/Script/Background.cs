﻿using UnityEngine;
using System.Collections;

public class Background : MonoBehaviour {

    private float speed = 0.1f;
    public Pocong pocong;
    public void mapRotation()
    {
        if (!pocong.getDead()) { 
        Vector2 offset = new Vector2(Time.time * speed, 0);
        GetComponent<Renderer>().material.mainTextureOffset = offset;
        transform.Translate(Vector3.right * PlayerPrefs.GetInt("speed") * Time.deltaTime);
        }
        else
        {
            Time.timeScale = 0.0f;
        }
        
    
    }
}
