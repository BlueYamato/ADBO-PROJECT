﻿using UnityEngine;
using System.Collections;

public abstract class Obstacle : MonoBehaviour {

	public abstract GameObject SelectObstacle ();
	public abstract Vector3 SpawnPoint();
}
