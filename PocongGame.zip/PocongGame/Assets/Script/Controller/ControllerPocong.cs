﻿using UnityEngine;
using System.Collections;

public class ControllerPocong : MonoBehaviour
{

    public Rigidbody2D rb;
    public Pocong pocong;
    // Use this for initialization
    void Start()
    {
        rb = pocong.getRigidBody2D();
        PlayerPrefs.SetInt("speed", 10);
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector3.right * PlayerPrefs.GetInt("speed") * Time.deltaTime);
        if (Input.GetKeyDown(KeyCode.UpArrow) && pocong.getJump() == false && pocong.getSleding() == false)
        {
            pocong.jump();
        }
         if (Input.GetKey(KeyCode.DownArrow) && pocong.getJump() == false)
        {
            pocong.duck();
        }
        else if (Input.GetKeyUp(KeyCode.DownArrow))
        {
            pocong.backToStandby();
        }
    }
}
