﻿using UnityEngine;
using System.Collections;

public class ObstacleController : MonoBehaviour {

	public Obstacle[] obs;
	public float timer;
    public Pocong pocong;

	void Update(){
		transform.Translate(Vector3.right * PlayerPrefs.GetInt("speed") * Time.deltaTime);
		timer -= Time.deltaTime;
		if (timer <= 0) {
			this.SpawnObstacle ();
			this.timer = Random.Range (2, 5);
		}
	}

	public void SpawnObstacle (){
        if (pocong.getDead()==false)
        {
            Obstacle selectedObstacle = obs[Random.Range(0, obs.Length)];
            GameObject obstacle = (GameObject)Instantiate(selectedObstacle.SelectObstacle(), selectedObstacle.SpawnPoint(), Quaternion.identity);
            //BoxCollider2Dnya ditambah di prefabnya aja biar ukuran box collidernya bisa diatur sendiri
        }
	}
}
