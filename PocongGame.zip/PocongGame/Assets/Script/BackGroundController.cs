﻿using UnityEngine;
using System.Collections;

public class BackGroundController : MonoBehaviour {

    public Background bg;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        bg.mapRotation();
	}
}
