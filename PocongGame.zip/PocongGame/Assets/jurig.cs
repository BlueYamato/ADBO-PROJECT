﻿using UnityEngine;
using System.Collections;

public class jurig : MonoBehaviour {
    public Pocong pocong;
	
	// Update is called once per frame
	void Update () {
        if (pocong.getDead()==true)
        {
            GetComponent<Animator>().Stop();
        }
}
}
