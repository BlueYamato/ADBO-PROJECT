﻿using UnityEngine;
using System.Collections;

public class DeleterRunner : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		transform.Translate(Vector3.right * PlayerPrefs.GetInt("speed") * Time.deltaTime);
	}

	void OnTriggerEnter2D(Collider2D collider){
		// Deleternya jg bisa ngehilangin si background yg dibelakang
		// Kalo mau sih tiap backgroundnya ancur, background baru dicreate lagi di depan
		Destroy (((BoxCollider2D)collider).gameObject);
	}
}
