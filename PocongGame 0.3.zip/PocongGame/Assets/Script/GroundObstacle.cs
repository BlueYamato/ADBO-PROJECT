﻿using UnityEngine;
using System.Collections;

public class GroundObstacle : Obstacle {

	
	public GameObject[] obstacle;

	public override GameObject SelectObstacle ()	{
		return obstacle [Random.Range (0, obstacle.Length)];
	}

	public override Vector3 SpawnPoint(){
		return transform.position;
	}
}
