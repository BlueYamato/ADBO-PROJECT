﻿using UnityEngine;
using System.Collections;

public class Selector : MonoBehaviour {

	float mark;
	GameObject[] quads;
	GameObject quad1;
	GameObject quad2;

	void Start(){
		this.mark = Random.Range (1, 5);
		this.quads = new GameObject[2];
		quad1 = this.gameObject.transform.GetChild (0).gameObject;
		quad2 = this.gameObject.transform.GetChild (1).gameObject;
		quads [0] = quad1;
		quads [1] = quad2;
	}

	// Update is called once per frame
	void Update () {
		mark -= Time.deltaTime;
		if (mark <= 0) {
			this.MakeObstacle ();
			this.mark = Random.Range (1, 5);
		}
	}

	void MakeObstacle(){
		int selector = Random.Range (0, 2);
		Obstacle obs = quads [selector].GetComponent<Obstacle>();
		obs.ObstacleMaker ();
	}
}
