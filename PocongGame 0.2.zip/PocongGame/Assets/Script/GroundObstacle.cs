﻿using UnityEngine;
using System.Collections;

public class GroundObstacle : Obstacle {

}
